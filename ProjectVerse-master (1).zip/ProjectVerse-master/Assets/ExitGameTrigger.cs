using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Verse
{
    public class ExitGameTrigger : MonoBehaviour
    {
        public void ExitGame() {
            Application.Quit();
        }

    }
}
