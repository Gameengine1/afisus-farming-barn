using Verse.API;

namespace DefaultNamespace {
    public class Entity {
    }

    public class TODO {
        #region Streamable Events

        private void OnEntityStreamIn(Entity entity) {
        }

        private void OnEntityStreamOut(Entity entity) {
        }

        private void OnEntityCreated(Entity entity) {
        }

        private void OnEntityDestroyed(Entity entity) {
        }

        private void OnConnected(Player player) {
        }

        private void OnAuthenticated(Player player) {
        }

        private void OnLoadRoom() {
        }

        private void OnUnloadRoom() {
        }

        #endregion
    }
}