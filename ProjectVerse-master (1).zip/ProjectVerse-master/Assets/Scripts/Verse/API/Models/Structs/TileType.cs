namespace Verse.API.Models {
    public enum TileType {
        Tile,
        TileObject,
        TileObjectEntity
    }
}