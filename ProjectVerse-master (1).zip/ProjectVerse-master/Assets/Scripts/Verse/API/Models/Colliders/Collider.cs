namespace Verse.API.Models.Colliders {
    public interface ICollider {
    }
}