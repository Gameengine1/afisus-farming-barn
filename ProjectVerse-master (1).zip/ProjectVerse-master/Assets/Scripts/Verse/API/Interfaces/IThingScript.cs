using System;

namespace Verse.API.Interfaces {
    public interface IThingScript {
        Type DataModel { get; }
    }
}