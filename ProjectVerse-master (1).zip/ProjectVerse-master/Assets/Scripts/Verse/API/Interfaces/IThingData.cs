namespace Verse.API.Interfaces {
    public interface IThingData {
    }
}