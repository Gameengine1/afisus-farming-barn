namespace UI {
    public interface ITileOperation {
        void Execute();
        void Undo();
    }
}