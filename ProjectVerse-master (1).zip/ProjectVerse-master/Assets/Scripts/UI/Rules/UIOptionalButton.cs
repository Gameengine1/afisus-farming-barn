﻿using UnityEngine;

public class UIOptionalButton : MonoBehaviour {
    public void Enable() {
    }
}