﻿using UnityEngine;

public class ColorChooserButton : MonoBehaviour {

    private int buttonID = 0;

    public int ButtonID
    {
        get { return buttonID; }
        set { buttonID = value; }
    }
}
