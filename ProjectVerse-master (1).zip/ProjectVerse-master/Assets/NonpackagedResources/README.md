These contain unity objects that serve as templates for modifying via the API/code. They will not be modifable via assets in the mod folder. 
